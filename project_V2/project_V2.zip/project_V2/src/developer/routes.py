from flask import render_template, redirect, url_for, Blueprint, flash
from .utils import developer_only
from src.models import Incident, db
from src.forms import DeveloperEditForm, MailForm
from src.mail import send_email

bp = Blueprint("developer", __name__)


@bp.route('/developer-dashboard', methods=['GET', 'POST'])
@developer_only
def developer_dashboard():
    incidents = Incident.query.all()
    return render_template('developer/index.html', incidents=incidents, title="Reported Bug Incident")


@bp.route('/developer-edit-report/<int:incident_id>', methods=['GET', 'POST'])
@developer_only
def developer_edit_bug_report(incident_id):
    incident = Incident.query.get(incident_id)
    form = DeveloperEditForm(
        time_stamps=incident.time_stamps,
        status=incident.status,
        resolution=incident.resolution
    )
    if form.validate_on_submit():
        incident.time_stamps = form.time_stamps.data
        incident.status = form.status.data
        incident.resolution = form.resolution.data
        db.session.commit()
        return redirect(url_for("developer.developer_dashboard"))

    return render_template('developer/form.html', form=form, title="Edit Bug Report")


@bp.route('/developer-send-mail/<int:incident_id>', methods=['GET', 'POST'])
@developer_only
def developer_send_mail(incident_id):
    incident = Incident.query.get(incident_id)
    form = MailForm()
    if form.validate_on_submit():
        print(incident.user_email)
        res = send_email(form.subject.data, form.body.data, incident.user_email)
        if res:
            flash('Sending email to the user', 'success')
        else:
            flash('Failed to send email, please try again later', 'error')
    return render_template('developer/form.html', form=form, title=f"Send Mail to {incident.user_email}")
