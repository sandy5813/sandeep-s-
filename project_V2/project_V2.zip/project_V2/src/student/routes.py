from flask import render_template, redirect, url_for, Blueprint, flash
from flask_login import current_user
from src.forms import StudentBugForm, MailForm
from .utils import student_only
from src.models import Incident, db
from src.mail import send_email

bp = Blueprint("student", __name__)


@bp.route('/student-dashboard', methods=['GET', 'POST'])
@student_only
def student_dashboard():
    incidents = Incident.query.filter_by(user=current_user).all()
    return render_template('student/index.html', incidents=incidents, title="Reported Bug Incident")


@bp.route('/add-report', methods=['GET', 'POST'])
@student_only
def student_add_bug_report():
    form = StudentBugForm()
    if form.validate_on_submit():
        new_incident = Incident(
            summary=form.summary.data,
            description=form.description.data,
            user_email=form.email.data,
            user=current_user,
            status="open"
        )
        db.session.add(new_incident)
        db.session.commit()
        return redirect(url_for("student.student_dashboard"))
    return render_template('student/form.html', form=form, title="Add Bug Report")


@bp.route('/edit-report/<int:incident_id>', methods=['GET', 'POST'])
@student_only
def student_edit_bug_report(incident_id):
    incident = Incident.query.get(incident_id)
    form = StudentBugForm(
        summary=incident.summary,
        description=incident.description,
        email=incident.user_email
    )
    if form.validate_on_submit():
        incident.summary = form.summary.data
        incident.description = form.description.data
        incident.user_email = form.email.data
        db.session.commit()
        return redirect(url_for("student.student_dashboard"))

    return render_template('student/form.html', form=form, title="Edit Bug Report")


@bp.route('/student-send-mail/<int:incident_id>', methods=['GET', 'POST'])
@student_only
def student_send_mail(incident_id):
    incident = Incident.query.get(incident_id)
    form = MailForm()
    if form.validate_on_submit():
        print(incident.user_email)
        res = send_email(form.subject.data, form.body.data, incident.developer_email)
        if res:
            flash('Sending email to the developer', 'success')
        else:
            flash('Failed to send email, please try again later', 'error')
    return render_template('student/form.html', form=form, title=f"Send Mail to {incident.developer_email}")
