from flask import render_template, redirect, url_for, Blueprint, flash
from src.forms import UserLoginFrom, StudentRegistrationForm
from flask_login import login_required, current_user, logout_user, login_user
from src.models import User, db

bp = Blueprint("auth", __name__)


@bp.route('/', methods=['GET', 'POST'])
def user_login():
    if current_user.is_authenticated:
        if current_user.role == 'student':
            return redirect(url_for('student.student_dashboard'))
        if current_user.role == 'admin':
            return redirect(url_for('admin.admin_dashboard'))
        if current_user.role == 'developer':
            return redirect(url_for('developer.developer_dashboard'))

    form = UserLoginFrom()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and user.check_password(form.password.data):
            login_user(user)
            flash('You are login now!', 'success')
            if current_user.role == 'student':
                return redirect(url_for('student.student_dashboard'))
            if current_user.role == 'admin':
                return redirect(url_for('admin.admin_dashboard'))
            if current_user.role == 'developer':
                return redirect(url_for('developer.developer_dashboard'))
        flash('Incorrect email and password', 'error')
    return render_template('auth/form.html', form=form, title="Login")


@bp.route('/logout')
@login_required
def user_logout():
    logout_user()
    flash("You have logged out", "info")
    return redirect(url_for('auth.user_login'))


@bp.route('/register', methods=['GET', 'POST'])
def user_register():
    if current_user.is_authenticated:
        if current_user.role == 'student':
            return redirect(url_for('student.student_dashboard'))
        if current_user.role == 'admin':
            return redirect(url_for('admin.admin_dashboard'))
        if current_user.role == 'developer':
            return redirect(url_for('developer.developer_dashboard'))

    register_form = StudentRegistrationForm()
    if register_form.validate_on_submit():
        if User.query.filter_by(username=register_form.username.data).first():
            flash("You've already sign up with that email, log in instead.", 'error')
            return redirect(url_for('auth.user_login'))
        else:
            new_user = User(name=register_form.name.data, email=register_form.email.data,
                            username=register_form.username.data, role="student")
            new_user.set_password(register_form.password.data)
            db.session.add(new_user)
            db.session.commit()
            login_user(new_user)
            return redirect(url_for('student.student_dashboard'))
    return render_template('auth/form.html', form=register_form, title="Register")
