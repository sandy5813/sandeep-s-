from wtforms import StringField, PasswordField, \
    SubmitField, TextAreaField, SelectField
from flask_wtf import FlaskForm
from wtforms.validators import DataRequired, Email, EqualTo, Length
from src.models import User

ROLE_CHOICES = [
    'admin',
    'developer'
]

TIMESTAMP_CHOICES = [
    '5',
    '10',
    '15',
    'Other'
]

STATUS_CHOICES = [
    'open',
    'assigned',
    'inprogress',
    'resolved',
]


def developer_choices():
    developers = User.query.filter_by(role='developer').all()
    available_developers = []
    if len(developers) > 0:
        available_developers = [(developer.id, developer.name) for developer in developers]

    return available_developers


class StudentRegistrationForm(FlaskForm):
    username = StringField(label='Username', validators=[DataRequired()])
    name = StringField(label='Name', validators=[DataRequired()])
    email = StringField(label='Email', validators=[DataRequired(), Email()])
    password = PasswordField(label='Password', validators=[DataRequired()])
    submit = SubmitField(label='Register')


class AddUserFrom(FlaskForm):
    username = StringField(label='Username', validators=[DataRequired()])
    name = StringField(label='Name', validators=[DataRequired()])
    email = StringField(label='Email', validators=[DataRequired(), Email()])
    password = PasswordField(label='Password', validators=[DataRequired()])
    role = SelectField(label='Role', choices=ROLE_CHOICES, validators=[DataRequired()])
    submit = SubmitField(label='Submit')


class AssignDeveloperFrom(FlaskForm):
    developer = SelectField(label='Select Developer', choices=developer_choices, validators=[DataRequired()])
    submit = SubmitField(label='Submit')


class DeveloperEditForm(FlaskForm):
    time_stamps = SelectField(label='Time stamps', choices=TIMESTAMP_CHOICES, validators=[DataRequired()])
    status = SelectField(label='Status', choices=STATUS_CHOICES, validators=[DataRequired()])
    resolution = TextAreaField(label='Resolution details', validators=[DataRequired()])
    submit = SubmitField(label='Submit')


class UserLoginFrom(FlaskForm):
    username = StringField(label='Username', validators=[DataRequired()])
    password = PasswordField(label='Password', validators=[DataRequired()])
    submit = SubmitField(label='Login')


class StudentBugForm(FlaskForm):
    summary = TextAreaField(label='Incident Summary', validators=[DataRequired()])
    description = TextAreaField(label='Incident Description', validators=[DataRequired()])
    email = StringField(label='Email', validators=[DataRequired(), Email()])
    submit = SubmitField(label='Submit')


class MailForm(FlaskForm):
    subject = StringField(label='Email Subject', validators=[DataRequired()])
    body = TextAreaField(label='Message', validators=[DataRequired()])
    submit = SubmitField(label='Submit')


class FilterForm(FlaskForm):
    filter = SelectField('Filter', choices=[
        (1, 'open'), (2, 'assigned'), (3, 'inprogress'), (4, 'resolved')])
