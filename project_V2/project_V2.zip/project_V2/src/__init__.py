from flask import Flask, render_template
from flask_bootstrap import Bootstrap5
from flask_login import LoginManager
from src.models import db, User, bcrypt
from flask_wtf.csrf import CSRFProtect
from flask_toastr import Toastr
from flask_mail import Mail
from flask_msearch import Search

import os

basedir = os.path.abspath(os.path.dirname(__file__))

mail = Mail()
search = Search()


def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'secret-key'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'database.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['MAIL_SERVER'] = 'smtp.gmail.com'
    app.config['MAIL_PORT'] = 465
    app.config['MAIL_USERNAME'] = os.environ.get('GMAIL_ADDRESS')
    app.config['MAIL_PASSWORD'] = os.environ.get('GMAIL_PASSWORD')
    app.config['MAIL_USE_TLS'] = False
    app.config['MAIL_USE_SSL'] = True

    app.config['TOASTR_POSITION_CLASS'] = 'toast-bottom-right'

    mail.init_app(app)
    Toastr(app)
    Bootstrap5(app)
    db.init_app(app)
    search.init_app(app)
    bcrypt.init_app(app)
    login_manager = LoginManager(app)
    login_manager.login_view = "auth.user_login"

    csrf = CSRFProtect()
    csrf.init_app(app)

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    from src.auth import routes
    app.register_blueprint(routes.bp)

    from src.admin import routes
    app.register_blueprint(routes.bp)

    from src.developer import routes
    app.register_blueprint(routes.bp)

    from src.student import routes
    app.register_blueprint(routes.bp)

    def page_not_found(e):
        return render_template('error/404.html'), 404

    app.register_error_handler(404, page_not_found)

    @app.before_first_request
    def create_table():
        if not os.path.exists(os.path.join(basedir, 'database.db')):
            db.create_all()
            print('database created')
        if not User.query.filter_by(username='admin').first():
            new_admin = User(username="admin", role="admin")
            new_admin.set_password('12345')
            db.session.add(new_admin)
            db.session.commit()
            print('admin created')

    return app
