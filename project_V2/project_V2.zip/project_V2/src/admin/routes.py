from flask import render_template, redirect, url_for, Blueprint, flash, request
from .utils import admin_only
from src.models import Incident, User, db
from src.forms import AddUserFrom, AssignDeveloperFrom, FilterForm

bp = Blueprint("admin", __name__)


@bp.route('/admin-dashboard', methods=['GET', 'POST'])
@admin_only
def admin_dashboard():
    form = FilterForm()
    incidents = Incident.query

    filter = request.args.get('filter')
    print('filter', filter)
    if filter != "" or filter is not None:
        form = FilterForm(filter=filter)
        if filter == '1':
            incidents = incidents.filter_by(status='open')
        if filter == '2':
            incidents = incidents.filter_by(status='assigned')
        if filter == '3':
            incidents = incidents.filter_by(status='inprogress')
        if filter == '4':
            incidents = incidents.filter_by(status='resolved')

    searchword = request.args.get('q')



    if searchword:
        incidents = incidents.msearch(searchword, fields=['developer_name']).all()

    return render_template('admin/index.html', incidents=incidents, title="All Reported Incidents",
                           form=form,
                           query=searchword
                           )


@bp.route('/admin-add-user', methods=['GET', 'POST'])
@admin_only
def admin_add_user():
    form = AddUserFrom()
    if form.validate_on_submit():
        if not User.query.filter_by(username=form.username.data).first():
            new_user = User(email=form.email.data, name=form.name.data, username=form.username.data,
                            role=form.role.data)
            new_user.set_password(form.password.data)
            db.session.add(new_user)
            db.session.commit()
            return redirect(url_for("admin.admin_dashboard"))
        else:
            flash('Username already taken', 'error')
    return render_template('admin/form.html', form=form, title="Add User")


@bp.route('/admin-assign-developer/<int:incident_id>', methods=['GET', 'POST'])
@admin_only
def admin_assign_developer(incident_id):
    print(incident_id)
    form = AssignDeveloperFrom()
    if form.validate_on_submit():
        print(form.developer.data)
        incident = Incident.query.get(incident_id)
        dev = User.query.get(int(form.developer.data))
        incident.developer_id = dev.id
        incident.developer_name = dev.name
        incident.developer_email = dev.email
        incident.status = "assigned"
        db.session.commit()
        return redirect(url_for("admin.admin_dashboard"))
    return render_template('admin/form.html', form=form, title="Assign Developer")


@bp.route('/admin-users', methods=['GET', 'POST'])
@admin_only
def admin_users():
    users = User.query.filter(User.role != "admin").all()
    return render_template('admin/users.html', users=users, title="All Users")


@bp.route('/admin-graph', methods=['GET', 'POST'])
@admin_only
def admin_graph():
    total_open = len(Incident.query.filter_by(status='open').all())
    total_assigned = len(Incident.query.filter_by(status='assigned').all())
    total_inprogress = len(Incident.query.filter_by(status='inprogress').all())
    total_resolved = len(Incident.query.filter_by(status='resolved').all())
    return render_template('admin/graph.html', title="Graph", total_open=total_open,
                           total_assigned=total_assigned,
                           total_inprogress=total_inprogress,
                           total_resolved=total_resolved)
