from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from flask_bcrypt import Bcrypt
from datetime import datetime

bcrypt = Bcrypt()
db = SQLAlchemy()


class TimestampMixin(object):
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, onupdate=datetime.utcnow)


class User(db.Model, UserMixin, TimestampMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(250), nullable=False, unique=True)
    name = db.Column(db.String(250), nullable=True)
    email = db.Column(db.String(250), nullable=True)
    password_hash = db.Column(db.String(250), nullable=False)
    role = db.Column(db.String(250), index=True, nullable=False)
    incidents = db.relationship("Incident", back_populates="user")

    def __repr__(self):
        return f'<User {self.username}>'

    def set_password(self, password):
        self.password_hash = bcrypt.generate_password_hash(password).decode('utf8')

    def check_password(self, password):
        try:
            return bcrypt.check_password_hash(self.password_hash, password)
        except Exception as e:
            print(e)
            return False


class Incident(db.Model, TimestampMixin):
    __searchable__ = ['developer_name']
    id = db.Column(db.Integer, primary_key=True)
    summary = db.Column(db.String(500), nullable=False)
    description = db.Column(db.Text, nullable=False)
    resolution = db.Column(db.Text, nullable=True)
    time_stamps = db.Column(db.String(50), nullable=True)
    status = db.Column(db.String(50), nullable=True)
    user_email = db.Column(db.String(250), nullable=False)
    developer_email = db.Column(db.String(250), nullable=True)
    developer_name = db.Column(db.String(250), nullable=True)
    developer_id = db.Column(db.Integer, nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    user = db.relationship("User", back_populates="incidents")

    def __repr__(self):
        return f'<Incident {self.id}>'
