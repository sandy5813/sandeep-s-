from flask_mail import Message
from src import mail
import os


def send_email(subject, mail_body, recipient_email):
    try:
        msg = Message(subject, sender=os.environ.get('GMAIL_ADDRESS'), recipients=[recipient_email])
        msg.body = mail_body
        mail.send(msg)
        return True
    except Exception as e:
        print(e)
        return False